export const navigationLinks = [
  { name: "Overview", href: "/" },
  { name: "Customers", href: "/customers" },
  { name: "Add customer", href: "/add-customer" },
  { name: "Orders", href: "/orders" },
  { name: "Products", href: "/products" },
];
