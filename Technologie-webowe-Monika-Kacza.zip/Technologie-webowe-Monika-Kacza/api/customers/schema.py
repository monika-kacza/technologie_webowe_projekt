from enum import Enum

from pydantic import BaseModel

class CustomerCreateSchema(BaseModel):
    imie: str
    nazwisko: str
    mail: str
    nrtelefonu: str

    class Config:
        schema_extra = {
            "example": {
                "imie": "Ania",
                "nazwisko": "Nowak",
                "mail": "ania.nowak@email.com",
                "nrtelefonu": "123-456-789",
            }
        }


class CustomerUpdateSchema(BaseModel):
    name: str | None
    surname: str | None
    email: str | None
    phone_number: str | None

    class Config:
        schema_extra = {
            "example": {
                "name": "Jan",
                "surname": "Kowalski"
            }
        }


class Customer(CustomerCreateSchema):
    id: int


